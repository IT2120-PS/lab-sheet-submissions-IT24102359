setwd("C:\\Users\\manod\\OneDrive\\Documents\\Y2 S1\\PS\\Lab_09")

y <- rnorm(25, mean = 45, sd = 2)
y

t.test(y, mu=46 , alternative = "less")